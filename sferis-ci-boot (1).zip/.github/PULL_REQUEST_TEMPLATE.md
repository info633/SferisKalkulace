## Co se mění
- [ ] Popište účel a přínos změn

## Dopad
- [ ] UI/UX
- [ ] Výpočet/Business logika
- [ ] Integrace/Deploy

## Testy
- [ ] Unit testy prošly
- [ ] E2E test prošel lokálně

## Migrace
- [ ] Není potřeba
- [ ] Je potřeba (popište co)
